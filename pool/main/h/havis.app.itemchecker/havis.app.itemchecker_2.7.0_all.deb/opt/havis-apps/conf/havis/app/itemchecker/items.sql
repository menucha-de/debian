CREATE TABLE IF NOT EXISTS items (
  id TEXT,
  code TEXT NOT NULL,
  description TEXT,
  quantity INT NOT NULL,
  state INT NOT NULL
);
