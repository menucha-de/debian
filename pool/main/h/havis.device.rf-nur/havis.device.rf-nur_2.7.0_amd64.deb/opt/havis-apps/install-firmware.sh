#!/bin/sh

. /etc/profile

./update-nur-firmware.sh manual